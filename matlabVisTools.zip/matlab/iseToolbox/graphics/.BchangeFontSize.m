function setFontSize(size,handles)
%
% setFontSize(size,[handles])
