%
% Stanford statistics tools
%
% max2 - max of matrix
% mean2 - mean of matrix
% min2 - min of matrix
% mse - mean squared difference between two matrices
% multiRandn - Draws a vector from a multivariate normal
%      distribution, given the mean and covariance
% sum2 - sum of matrix elements

