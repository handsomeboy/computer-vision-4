function res = max2(mtx)
% MAX2: Max of a matrix.
%
% m = max2(mtx)
%

res = max(max(mtx));
