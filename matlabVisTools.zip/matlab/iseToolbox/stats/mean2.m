function res = mean2(mtx)
% MEAN2: Sample mean of a matrix.
%
% m = mean2(mtx)

res = mean(mean(mtx));
