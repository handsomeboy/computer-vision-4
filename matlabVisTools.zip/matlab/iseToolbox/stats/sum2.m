function res = sum2(mtx)
% SUM2: sum of matrix elements.
%
% m = sum2(mtx)

res = sum(sum(mtx));
