function res = min2(mtx)
% MIN2: Min of a matrix.
% 
% m = min2(mtx)

res = min(min(mtx));
