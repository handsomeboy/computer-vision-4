function result = rsqrd(y,x)
% RSQRD: Example for how to use makeSyntheticImage
%
% DJH '96

result = x.^2 + y.^2;
