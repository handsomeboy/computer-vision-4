function result = rsqrd(y,x)
% RSQRD: Example for how to use mkSyntheticImage
%
% DJH '96

result = x.^2 + y.^2;
