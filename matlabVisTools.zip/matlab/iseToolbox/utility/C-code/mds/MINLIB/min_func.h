#ifndef _min_func_h_
#define _min_func_h_
#include <matrix.h>

matrix param_min();
matrix param_dmin();

#endif
