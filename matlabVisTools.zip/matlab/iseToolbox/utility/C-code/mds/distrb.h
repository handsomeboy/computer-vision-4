#ifndef _distrb_h_
#define _distrb_h_

double gss_distr(),unif_distr();

#endif