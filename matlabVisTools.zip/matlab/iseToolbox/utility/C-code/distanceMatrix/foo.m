tic
for i=1:50
 distanceMatrix(coords);
end
toc
