function a = ginput()
 a = [3 3];
